package com.lsk.community.back.common.utils;

import java.util.Map;

public class DebugUtil {
	public void printMap(String prefix, Map<?, ?> map) {}
}
