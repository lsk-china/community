package com.lsk.community.back.common.utils;

public class EmptyDebugUtil extends DebugUtil{
}
